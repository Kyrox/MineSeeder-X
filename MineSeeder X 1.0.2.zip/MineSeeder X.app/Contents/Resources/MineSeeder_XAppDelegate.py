#
#  MineSeeder_XAppDelegate.py
#  MineSeeder X
#
#  Created by Kyrox on 11-01-24.
#  Copyright __MyCompanyName__ 2011. All rights reserved.
#

from Foundation import *
from AppKit import *

class MineSeeder_XAppDelegate(NSObject):
    def applicationDidFinishLaunching_(self, sender):
        #NSLog("Application did finish launching.")
